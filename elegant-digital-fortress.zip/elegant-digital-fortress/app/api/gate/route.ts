import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { Redis } from '@upstash/redis';
import { Ratelimit } from '@upstash/ratelimit';
import { prisma } from '@/lib/prisma';
import { createSessionToken, hashForAudit, safeEqualText } from '@/lib/security';

export const runtime = 'nodejs';
const schema = z.object({
  fullName: z.string().trim().min(2).max(100),
  email: z.email().max(254),
  phone: z.string().trim().regex(/^\+?[0-9 ()-]{8,22}$/),
  profession: z.enum(['student', 'technology', 'education', 'business', 'other']),
  purpose: z.enum(['learn', 'work', 'explore', 'other']),
  consent: z.literal(true),
  answers: z.array(z.string().max(80)).length(3),
  turnstileToken: z.string().optional()
});

const answerKey = ['photosynthesis', 'pacific', '7'];

async function verifyTurnstile(token: string | undefined, ip: string) {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret) {
    if (process.env.NODE_ENV === 'production') return false;
    return true; // Local development only. Production requires the real Turnstile secret.
  }
  if (!token) return false;
  const body = new URLSearchParams({ secret, response: token, remoteip: ip });
  const response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
    method: 'POST', body, cache: 'no-store'
  });
  if (!response.ok) return false;
  const result = await response.json() as { success?: boolean };
  return result.success === true;
}

export async function POST(request: NextRequest) {
  const origin = request.headers.get('origin');
  const appOrigin = process.env.APP_ORIGIN;
  if (!appOrigin || origin !== appOrigin) {
    return NextResponse.json({ error: 'Permintaan tidak valid.' }, { status: 403 });
  }

  const redisUrl = process.env.UPSTASH_REDIS_REST_URL;
  const redisToken = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!redisUrl || !redisToken) {
    return NextResponse.json({ error: 'Layanan verifikasi belum dikonfigurasi.' }, { status: 503 });
  }

  const forwarded = request.headers.get('x-forwarded-for');
  // Configure trusted proxy headers at your hosting provider. Never trust arbitrary client IP headers.
  const ip = (forwarded?.split(',')[0]?.trim() || 'unknown').slice(0, 64);
  const redis = new Redis({ url: redisUrl, token: redisToken });
  const limiter = new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(3, '15 m'), prefix: 'edf:gate' });
  const limit = await limiter.limit(ip);
  if (!limit.success) {
    return NextResponse.json({ error: 'Terlalu banyak percobaan. Coba lagi nanti.' }, {
      status: 429, headers: { 'Retry-After': String(Math.ceil((limit.reset - Date.now()) / 1000)) }
    });
  }

  let raw: unknown;
  try { raw = await request.json(); }
  catch { return NextResponse.json({ error: 'Format permintaan tidak valid.' }, { status: 400 }); }
  const parsed = schema.safeParse(raw);
  if (!parsed.success) return NextResponse.json({ error: 'Periksa kembali data yang kamu isi.' }, { status: 400 });
  const data = parsed.data;

  if (!(await verifyTurnstile(data.turnstileToken, ip))) {
    return NextResponse.json({ error: 'Verifikasi keamanan gagal. Silakan coba kembali.' }, { status: 400 });
  }
  const answersCorrect = data.answers.every((answer, index) => safeEqualText(answer, answerKey[index]));
  if (!answersCorrect) {
    await prisma.auditEvent.create({ data: { event: 'gate.challenge_failed', ipHash: hashForAudit(ip) } });
    return NextResponse.json({ error: 'Jawaban verifikasi belum tepat. Periksa kembali.' }, { status: 400 });
  }

  try {
    const submission = await prisma.gateSubmission.create({ data: {
      fullName: data.fullName, email: data.email.toLowerCase(), phone: data.phone,
      profession: data.profession, visitPurpose: data.purpose, consentVersion: 'privacy-v1'
    } });
    await prisma.auditEvent.create({ data: {
      event: 'gate.verified', subjectHash: hashForAudit(data.email.toLowerCase()), ipHash: hashForAudit(ip),
      details: { submissionId: submission.id }
    } });
    const token = await createSessionToken(submission.id);
    const response = NextResponse.json({ ok: true, message: 'Verifikasi berhasil.' });
    response.cookies.set('edf_session', token, {
      httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax',
      path: '/', maxAge: 20 * 60
    });
    return response;
  } catch (error) {
    console.error('gate_submission_failed', error instanceof Error ? error.name : 'unknown');
    return NextResponse.json({ error: 'Layanan sedang mengalami gangguan. Coba lagi nanti.' }, { status: 500 });
  }
}

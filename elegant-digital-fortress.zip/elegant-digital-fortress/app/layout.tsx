import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Elegant Digital Fortress — A calmer kind of security',
  description: 'A refined digital sanctuary where thoughtful design meets layered security.',
  applicationName: 'Elegant Digital Fortress',
  robots: { index: true, follow: true },
  openGraph: {
    title: 'Elegant Digital Fortress',
    description: 'Thoughtful design. Quiet confidence. Layered security.',
    type: 'website'
  }
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#1B3A2F' };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}

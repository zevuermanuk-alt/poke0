import { Gatekeeper } from '@/components/Gatekeeper';

export default function HomePage() {
  return <main><Gatekeeper /></main>;
}

'use client';

import { useEffect, useRef, useState, type FormEvent } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { LeafCanvas } from '@/components/LeafCanvas';
import { Scene3D } from '@/components/Scene3D';

declare global {
  interface Window { turnstile?: { render: (el: HTMLElement, opts: Record<string, unknown>) => string; reset: (id?: string) => void } }
}

const QUESTIONS = [
  { label: 'Apa nama proses tumbuhan membuat makanan dengan cahaya matahari?', placeholder: 'Jawaban singkat' },
  { label: 'Samudra terbesar di bumi bernama?', placeholder: 'Nama samudra' },
  { label: 'Berapa jumlah sisi pada segi tujuh?', placeholder: 'Angka' }
];

export function Gatekeeper() {
  const [verified, setVerified] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [dark, setDark] = useState(true);
  const [rain, setRain] = useState(false);
  const [sound, setSound] = useState(false);
  const [logoClicks, setLogoClicks] = useState(0);
  const [turnstileToken, setTurnstileToken] = useState('');
  const turnstileRef = useRef<HTMLDivElement>(null);
  const turnstileWidget = useRef<string | null>(null);

  useEffect(() => {
    const hour = new Date().getHours();
    document.documentElement.dataset.time = hour < 11 ? 'morning' : hour < 16 ? 'day' : hour < 19 ? 'evening' : 'night';
  }, []);

  useEffect(() => {
    const siteKey = process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY;
    if (!siteKey || !turnstileRef.current) return;
    const script = document.createElement('script');
    script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
    script.async = true;
    script.defer = true;
    script.onload = () => {
      if (window.turnstile && turnstileRef.current) {
        turnstileWidget.current = window.turnstile.render(turnstileRef.current, {
          sitekey: siteKey,
          callback: (token: string) => setTurnstileToken(token),
          'expired-callback': () => setTurnstileToken(''),
          theme: 'dark'
        });
      }
    };
    document.head.appendChild(script);
    return () => { script.remove(); };
  }, []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setNotice('');
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const data = new FormData(form);
    const payload = {
      fullName: String(data.get('fullName') || ''),
      email: String(data.get('email') || ''),
      phone: String(data.get('phone') || ''),
      profession: String(data.get('profession') || ''),
      purpose: String(data.get('purpose') || ''),
      consent: data.get('consent') === 'on',
      answers: [String(data.get('answer0') || ''), String(data.get('answer1') || ''), String(data.get('answer2') || '')],
      turnstileToken: turnstileToken || undefined
    };
    setLoading(true);
    try {
      const response = await fetch('/api/gate', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), credentials: 'same-origin'
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Verifikasi gagal. Coba kembali.');
      setVerified(true); setNotice('Akses terverifikasi. Selamat datang di ruang digital yang lebih tenang.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Terjadi kesalahan. Silakan coba kembali.');
      if (turnstileWidget.current) window.turnstile?.reset(turnstileWidget.current);
      setTurnstileToken('');
    } finally { setLoading(false); }
  }

  function logoClick() {
    const next = logoClicks + 1; setLogoClicks(next);
    if (next >= 5) { setRain(true); setNotice('Forest rain mode unlocked.'); setLogoClicks(0); window.setTimeout(() => setNotice(''), 3500); }
  }

  return <div className={`app-shell ${dark ? 'theme-dark' : 'theme-light'} ${rain ? 'rain-mode' : ''}`}>
    <LeafCanvas />
    <div className="grain" aria-hidden="true" />
    <header className="site-header">
      <button className="wordmark" onClick={logoClick} aria-label="Elegant Digital Fortress logo, click five times for an easter egg">
        <span className="mark-symbol">e<span>·</span>f</span><span className="wordmark-text">ELEGANT <b>DIGITAL</b><small>FORTRESS / EST. 2026</small></span>
      </button>
      <nav className="header-links" aria-label="Main navigation">
        <a href="#philosophy">Philosophy</a><a href="#layers">The layers</a><a href="#trust">Trust</a>
      </nav>
      <div className="header-tools">
        <button className="icon-button" onClick={() => setDark(v => !v)} aria-label="Toggle light and dark theme" title="Toggle theme">{dark ? '☼' : '☾'}</button>
        <button className={`icon-button ${sound ? 'is-active' : ''}`} onClick={() => setSound(v => !v)} aria-label="Toggle ambience setting" title="Ambience setting">♫</button>
        <span className="secure-pill"><i /> SECURE SPACE</span>
      </div>
    </header>

    {!verified ? <section className="gate-layout">
      <div className="gate-copy">
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7 }}>
          <span className="eyebrow"><span className="eyebrow-line" /> A MORE HUMAN KIND OF SECURITY</span>
          <h1>Enter a quieter<br /><em>kind of fortress.</em></h1>
          <p className="lead">A considered digital sanctuary, shaped by nature and protected by intention. A small pause before you step inside.</p>
          <div className="gate-visual">
            <Scene3D />
            <div className="orbit orbit-one" /><div className="orbit orbit-two" />
            <div className="visual-caption"><span>01 / THE THRESHOLD</span><span>DESIGNED TO FEEL DIFFERENT</span></div>
          </div>
          <div className="manifesto"><span className="manifesto-mark">✳</span><p>“Security should feel less like a wall,<br />and more like a place worth protecting.”</p></div>
        </motion.div>
      </div>

      <motion.div className="gate-card-wrap" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7, delay: .15 }}>
        <div className="gate-card">
          <div className="card-topline"><span>ACCESS PROTOCOL / 001</span><span className="live-dot">● SYSTEM READY</span></div>
          <div className="card-heading"><div className="shield-icon">⌑</div><div><h2>Before we begin.</h2><p>Tell us a little about yourself.</p></div></div>
          <div className="progress-steps"><span className="step-active">01 <i>Profile</i></span><b /><span>02 <i>Verify</i></span><b /><span>03 <i>Enter</i></span></div>
          <form onSubmit={handleSubmit} className="gate-form">
            <label className="floating-field"><span>Full name *</span><input name="fullName" placeholder="e.g. Alex Morgan" autoComplete="name" minLength={2} maxLength={100} required /></label>
            <label className="floating-field"><span>Email address *</span><input name="email" type="email" placeholder="you@example.com" autoComplete="email" maxLength={254} required /></label>
            <label className="floating-field"><span>Phone number *</span><input name="phone" type="tel" placeholder="+62 812 3456 7890" autoComplete="tel" minLength={8} maxLength={22} required /></label>
            <div className="form-grid">
              <label className="select-field"><span>Your field</span><select name="profession" required defaultValue=""><option value="" disabled>Select field</option><option value="student">Student</option><option value="technology">Technology</option><option value="education">Education</option><option value="business">Business</option><option value="other">Other</option></select></label>
              <label className="select-field"><span>Purpose</span><select name="purpose" required defaultValue=""><option value="" disabled>Choose one</option><option value="learn">Learning</option><option value="work">Work</option><option value="explore">Exploring</option><option value="other">Other</option></select></label>
            </div>
            <div className="challenge-box"><div className="challenge-heading"><span className="challenge-number">✳</span><div><b>A moment of mindfulness</b><small>Answer these three quick questions.</small></div></div>
              {QUESTIONS.map((q, i) => <label className="question-field" key={q.label}><span>{i+1}. {q.label}</span><input name={`answer${i}`} placeholder={q.placeholder} required maxLength={80} autoComplete="off" /></label>)}
              <div ref={turnstileRef} className="turnstile-slot" />
            </div>
            <label className="consent-row"><input type="checkbox" name="consent" required /><span>I agree to the <a href="#privacy">privacy notice</a> and consent to the processing of the details above for access verification. *</span></label>
            <p className="privacy-caption">We use your information only for the purpose explained here. Avoid submitting sensitive personal information.</p>
            {error && <div className="form-message error-message" role="alert">{error}</div>}
            <button className="primary-button" type="submit" disabled={loading}>{loading ? <><span className="spinner" /> Verifying securely…</> : <>Verify & enter <span>↗</span></>}</button>
            <p className="secure-foot"><span>♢</span> Protected in transit · Short-lived session · Minimal data</p>
          </form>
        </div>
      </motion.div>
    </section> : <>
      <section className="hero-section" id="philosophy">
        <div className="hero-copy"><span className="eyebrow"><span className="eyebrow-line" /> DESIGN WITH INTENTION / SECURITY BY NATURE</span><h1>Quiet strength.<br /><em>Beautifully protected.</em></h1><p className="lead">A digital environment where every detail has a purpose. Grounded in nature. Built around trust. Crafted to feel effortless.</p><div className="hero-actions"><a className="primary-button link-button" href="#layers">Explore the layers <span>↘</span></a><a className="text-link" href="#trust">Our philosophy <span>↗</span></a></div><div className="hero-meta"><span><i /> INTENTIONALLY DESIGNED</span><span>01 — 04 / PRINCIPLES</span></div></div>
        <div className="hero-art"><Scene3D /><div className="hero-orbit orbit-one"/><div className="hero-orbit orbit-two"/><div className="hero-art-label"><span>FIG. 01</span><b>Nature in balance</b><small>FORM / FUNCTION / FEELING</small></div><div className="hero-vertical">ELEGANT DIGITAL FORTRESS · 2026</div></div>
      </section>
      <section className="philosophy-section section-pad"><div className="section-kicker">01 / OUR PHILOSOPHY</div><div className="philosophy-grid"><h2>Technology can be<br /><em>protective and poetic.</em></h2><div><p>We believe the most meaningful digital experiences are not the loudest. They are clear, considered and calm — with strong foundations that work quietly in the background.</p><a className="text-link" href="#layers">Discover our principles <span>↗</span></a></div></div><div className="principle-strip"><div><span>01</span><b>Clarity over noise</b><small>Every interaction earns its place.</small></div><div><span>02</span><b>Nature as a guide</b><small>Organic motion, balanced by restraint.</small></div><div><span>03</span><b>Trust by design</b><small>Privacy and safety are considered early.</small></div></div></section>
      <section className="layers-section section-pad" id="layers"><div className="section-kicker">02 / THE LAYERS</div><div className="section-title-row"><h2>Thoughtful by nature.<br /><em>Precise by design.</em></h2><p>Four principles, one coherent experience. Each layer is designed to make the complex feel beautifully simple.</p></div><div className="feature-grid"><article className="feature-card"><div className="feature-art art-leaf">✳<span>01</span></div><small>THE EXPERIENCE</small><h3>Organic intelligence</h3><p>Living motion and responsive details that feel natural rather than mechanical.</p><a href="#trust" aria-label="Learn about organic intelligence">Explore principle ↗</a></article><article className="feature-card"><div className="feature-art art-orb">◉<span>02</span></div><small>THE INTERFACE</small><h3>Quiet precision</h3><p>Intentional typography, balanced space and useful interactions without visual noise.</p><a href="#trust" aria-label="Learn about quiet precision">Explore principle ↗</a></article><article className="feature-card"><div className="feature-art art-shield">⌑<span>03</span></div><small>THE FOUNDATION</small><h3>Layered protection</h3><p>Server-side validation, limited sessions and security controls that can be audited.</p><a href="#trust" aria-label="Learn about layered protection">Explore principle ↗</a></article><article className="feature-card"><div className="feature-art art-water">≈<span>04</span></div><small>THE FEELING</small><h3>Calm by default</h3><p>Reduced-motion support, readable contrast and predictable behavior across devices.</p><a href="#trust" aria-label="Learn about calm by default">Explore principle ↗</a></article></div></section>
      <section className="trust-section section-pad" id="trust"><div className="trust-visual"><div className="shield-large"><span>⌑</span><i /><b>TRUST</b></div><div className="trust-orbit"/><span className="trust-caption">A FOUNDATION YOU CAN BUILD ON</span></div><div className="trust-copy"><div className="section-kicker">03 / TRUST, NOT THEATRE</div><h2>Security should be<br /><em>quietly dependable.</em></h2><p>Visual polish is only one part of trust. Real protection comes from server-side controls, careful data handling, reliable infrastructure and honest communication about what is — and is not — active.</p><ul className="trust-list"><li><span>✓</span><div><b>Server-side validation</b><small>Inputs are checked again at the API boundary.</small></div></li><li><span>✓</span><div><b>Short-lived session cookie</b><small>HttpOnly and SameSite controls reduce exposure.</small></div></li><li><span>✓</span><div><b>Abuse throttling</b><small>Rate limits require a configured Redis service.</small></div></li><li><span>✓</span><div><b>Human-friendly accessibility</b><small>Keyboard access and reduced motion are supported.</small></div></li></ul><p className="honesty-note">Security controls depend on correct production configuration. This demonstration is not a certification or guarantee of security.</p></div></section>
      <section className="closing-section section-pad"><div className="closing-symbol">✳</div><span className="eyebrow">THE NEXT CHAPTER STARTS HERE</span><h2>Make room for<br /><em>what matters.</em></h2><p>Good design doesn't demand attention. It earns confidence.</p><a className="primary-button link-button" href="#philosophy">Return to the beginning <span>↑</span></a></section>
    </>}

    <footer className="site-footer" id="privacy"><div className="footer-brand"><span className="mark-symbol">e<span>·</span>f</span><div><b>ELEGANT DIGITAL FORTRESS</b><small>CALM BY DESIGN. SECURE BY INTENTION.</small></div></div><p>Thoughtful digital spaces for a more considered world.</p><div className="footer-bottom"><span>© 2026 ELEGANT DIGITAL FORTRESS</span><span>MADE WITH INTENTION <i>✳</i></span><button onClick={() => { setRain(v => !v); setNotice(!rain ? 'Forest rain mode enabled.' : 'Forest rain mode disabled.'); window.setTimeout(() => setNotice(''), 3000); }}>Forest mode {rain ? 'on' : 'off'}</button></div></footer>
    <AnimatePresence>{notice && <motion.div className="toast" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }} role="status"><span>✳</span>{notice}</motion.div>}</AnimatePresence>
    <div className="scroll-progress" aria-hidden="true"><span /></div>
    <div className="sound-state" aria-live="polite">{sound ? 'Ambience preference enabled — audio is not loaded in this build.' : ''}</div>
  </div>;
}

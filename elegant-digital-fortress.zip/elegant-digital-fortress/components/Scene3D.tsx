'use client';

import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Sparkles } from '@react-three/drei';
import { useRef } from 'react';
import * as THREE from 'three';

function Orb({ position, scale, speed }: { position: [number, number, number]; scale: number; speed: number }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame(({ clock, pointer }) => {
    if (!ref.current) return;
    const t = clock.getElapsedTime();
    ref.current.rotation.y = t * 0.16 * speed + pointer.x * 0.15;
    ref.current.rotation.x = t * 0.1 + pointer.y * 0.1;
    ref.current.position.y = position[1] + Math.sin(t * speed) * 0.16;
  });
  return <Float speed={1.1} rotationIntensity={0.25} floatIntensity={0.35}>
    <mesh ref={ref} position={position} scale={scale}>
      <icosahedronGeometry args={[1, 2]} />
      <meshPhysicalMaterial color="#c9a961" roughness={0.18} metalness={0.55} transparent opacity={0.82} transmission={0.12} clearcoat={1} />
    </mesh>
  </Float>;
}

export function Scene3D() {
  return <div className="scene3d" aria-hidden="true">
    <Canvas camera={{ position: [0, 0, 6], fov: 42 }} dpr={[1, 1.5]} gl={{ alpha: true, antialias: true }}>
      <ambientLight intensity={1.4} />
      <pointLight position={[2, 3, 4]} intensity={24} color="#f5e6bd" />
      <pointLight position={[-3, -2, 2]} intensity={9} color="#7d9a80" />
      <Orb position={[0.7, 0.2, 0]} scale={0.9} speed={0.8} />
      <Orb position={[-1.5, -0.7, -1]} scale={0.35} speed={1.2} />
      <Orb position={[1.9, 1.15, -1.8]} scale={0.22} speed={1.6} />
      <Sparkles count={42} scale={5} size={1.5} speed={0.25} color="#c9a961" opacity={0.7} />
    </Canvas>
  </div>;
}

'use client';

import { useEffect, useRef } from 'react';

// Five bespoke leaf silhouettes. Canvas draws these at runtime so each leaf can rotate,
// sway, glow and be reused without creating 30 DOM nodes.
const SHAPES = [
  'M0,-18 C12,-13 15,-2 0,18 C-14,6 -12,-9 0,-18 Z',
  'M0,-18 C17,-11 11,8 0,18 C-10,8 -17,-11 0,-18 Z',
  'M0,-18 C7,-10 19,-5 11,7 C6,12 3,15 0,18 C-5,8 -16,1 -9,-9 Z',
  'M0,-18 C14,-14 20,-3 7,10 L0,18 L-7,10 C-20,-3 -14,-14 0,-18 Z',
  'M0,-18 C4,-8 18,-10 14,2 C11,12 3,13 0,18 C-3,13 -11,12 -14,2 C-18,-10 -4,-8 0,-18 Z'
];

type Leaf = { x:number; y:number; vx:number; vy:number; r:number; vr:number; sway:number; size:number; shape:number; hue:number; active:boolean; clicked:boolean; butterfly:number; slow:number };
const MAX = 30;

export function LeafCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef<{ leaves: Leaf[]; pointer: {x:number;y:number;active:boolean}; pool: {x:number;radius:number;alpha:number}[]; bursts: {x:number;y:number;life:number}[]; frame:number }>({
    leaves: [], pointer: { x: -9999, y: -9999, active: false }, pool: [], bursts: [], frame: 0
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const state = stateRef.current;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let width = 0, height = 0, raf = 0, lastSpawn = 0;
    const rand = (a:number,b:number) => a + Math.random()*(b-a);
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      width = window.innerWidth; height = window.innerHeight;
      canvas.width = Math.floor(width*dpr); canvas.height = Math.floor(height*dpr);
      canvas.style.width = `${width}px`; canvas.style.height = `${height}px`;
      ctx.setTransform(dpr,0,0,dpr,0,0);
    };
    const spawn = () => {
      if (state.leaves.length >= MAX) return;
      state.leaves.push({ x:rand(0,width), y:rand(-100,-20), vx:rand(-.25,.25), vy:rand(.35,.95), r:rand(0,6), vr:rand(-.015,.015), sway:rand(0,7), size:rand(8,17), shape:Math.floor(rand(0,SHAPES.length)), hue:rand(-8,10), active:true, clicked:false, butterfly:0, slow:1 });
    };
    const drawLeaf = (leaf:Leaf) => {
      ctx.save(); ctx.translate(leaf.x,leaf.y); ctx.rotate(leaf.r);
      ctx.scale(leaf.size/18, leaf.size/18);
      ctx.shadowColor = leaf.slow < 1 ? 'rgba(201,169,97,.8)' : 'transparent';
      ctx.shadowBlur = leaf.slow < 1 ? 14 : 0;
      ctx.fillStyle = leaf.butterfly > 0 ? '#c9a961' : `hsl(${105+leaf.hue}, 22%, ${48+leaf.hue/2}%)`;
      const path = new Path2D(SHAPES[leaf.shape]); ctx.fill(path);
      ctx.shadowBlur = 0; ctx.strokeStyle = 'rgba(245,240,230,.45)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(0,-15); ctx.lineTo(0,15); ctx.stroke();
      if (leaf.butterfly > 0) { ctx.fillStyle = '#e8d7a9'; ctx.beginPath(); ctx.ellipse(-5,0,5,8,Math.sin(leaf.butterfly)*.7,0,Math.PI*2); ctx.ellipse(5,0,5,8,-Math.sin(leaf.butterfly)*.7,0,Math.PI*2); ctx.fill(); }
      ctx.restore();
    };
    const tick = (now:number) => {
      state.frame++;
      ctx.clearRect(0,0,width,height);
      if (!reduced && now-lastSpawn > 520 && state.leaves.length < MAX) { spawn(); lastSpawn = now; }
      // Bottom pool and ripples.
      state.pool = state.pool.filter(p => p.alpha > 0.02);
      state.pool.forEach(p => { ctx.beginPath(); ctx.ellipse(p.x,height-12,p.radius,Math.max(2,p.radius*.22),0,0,Math.PI*2); ctx.strokeStyle=`rgba(201,169,97,${p.alpha})`; ctx.lineWidth=1; ctx.stroke(); p.radius += .55; p.alpha *= .965; });
      state.leaves = state.leaves.filter(l => l.active && l.y < height+40);
      state.leaves.forEach(leaf => {
        const dx = leaf.x-state.pointer.x, dy=leaf.y-state.pointer.y, dist=Math.hypot(dx,dy);
        leaf.slow = state.pointer.active && dist < 65 ? .28 : 1;
        if (state.pointer.active && dist < 90) { const force=(90-dist)/90; leaf.vx += (dx/(dist||1))*force*.08; leaf.vy -= force*.015; }
        leaf.sway += .012;
        leaf.vx += Math.sin(leaf.sway)*.012;
        leaf.vx *= .995; leaf.vy = Math.max(.18,Math.min(1.5,leaf.vy+.002));
        leaf.x += leaf.vx*leaf.slow; leaf.y += leaf.vy*leaf.slow; leaf.r += leaf.vr*leaf.slow;
        if (leaf.butterfly > 0) { leaf.butterfly += .12; leaf.vx += Math.sin(leaf.butterfly)*.03; leaf.vy = -.45 + Math.cos(leaf.butterfly)*.1; }
        if (leaf.clicked) { leaf.size *= .975; leaf.vy += .08; if (leaf.size < 3) leaf.active=false; }
        if (leaf.y > height-25 && !leaf.clicked) { state.pool.push({x:leaf.x,radius:2,alpha:.5}); leaf.active=false; }
        drawLeaf(leaf);
      });
      state.bursts = state.bursts.filter(b=>b.life>0);
      state.bursts.forEach(b=>{ for(let i=0;i<6;i++){const a=(i/6)*Math.PI*2;ctx.beginPath();ctx.arc(b.x+Math.cos(a)*(14-b.life*2),b.y+Math.sin(a)*(14-b.life*2),1.4,0,Math.PI*2);ctx.fillStyle=`rgba(201,169,97,${b.life/12})`;ctx.fill();} b.life--; });
      if (!reduced) raf=requestAnimationFrame(tick);
    };
    resize();
    for(let i=0;i<10;i++) spawn();
    if (reduced) { ctx.clearRect(0,0,width,height); state.leaves.slice(0,5).forEach((l,i)=>{l.x=width*(.15+i*.17);l.y=80+(i%2)*50;drawLeaf(l);}); }
    else raf=requestAnimationFrame(tick);
    const pointerMove = (e:PointerEvent) => { state.pointer={x:e.clientX,y:e.clientY,active:true}; };
    const pointerOut = () => { state.pointer.active=false; };
    const click = (e:MouseEvent) => {
      const target=e.target as HTMLElement;
      if(target.closest('button,a,input,textarea,select')) return;
      const leaf=state.leaves.find(l=>l.active && Math.hypot(l.x-e.clientX,l.y-e.clientY)<Math.max(20,l.size+8));
      if(!leaf) return;
      if(e.detail>=2){ leaf.butterfly=1; leaf.vy=-.4; }
      else { leaf.clicked=true; state.bursts.push({x:leaf.x,y:leaf.y,life:12}); state.pool.push({x:leaf.x,radius:2,alpha:.7}); }
    };
    window.addEventListener('resize',resize); window.addEventListener('pointermove',pointerMove,{passive:true}); window.addEventListener('pointerleave',pointerOut); window.addEventListener('click',click);
    return ()=>{ cancelAnimationFrame(raf); window.removeEventListener('resize',resize); window.removeEventListener('pointermove',pointerMove); window.removeEventListener('pointerleave',pointerOut); window.removeEventListener('click',click); };
  },[]);

  return <canvas ref={canvasRef} className="leaf-canvas" aria-hidden="true" />;
}

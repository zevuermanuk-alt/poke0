# Elegant Digital Fortress

A Next.js App Router design system / security-gate foundation with a forest-and-ivory visual language, Three.js floating orbs, canvas-based falling leaves, responsive layout, reduced-motion support, a profile gate, server-side validation, short-lived HttpOnly session cookie, Prisma schema, audit events, Redis-backed rate limiting and a Cloudflare Turnstile integration point.

> **Deployment status:** this is a security-conscious starter, not a certified or fully audited production product. A successful gate creates a short-lived `gate:verified` session; it does not implement account registration, password login, account recovery, authorization for private business data, or a complete privacy/compliance workflow. Review and test it before collecting real customer data.

## Requirements

- Node.js 20.9+ (use a supported current LTS release)
- npm
- PostgreSQL
- Upstash Redis REST credentials for the rate limiter
- Cloudflare Turnstile site and secret keys for production

## Local setup

1. Copy `.env.example` to `.env`.
2. Fill `DATABASE_URL`, `SESSION_SECRET`, `APP_ORIGIN`, `UPSTASH_REDIS_REST_URL`, and `UPSTASH_REDIS_REST_TOKEN`.
3. Generate a strong secret with `openssl rand -base64 48`; use the result for `SESSION_SECRET`.
4. Set up a PostgreSQL database and run:

   ```bash
   npm install
   npx prisma generate
   npx prisma migrate dev --name initial
   npm run dev
   ```

5. Visit `http://localhost:3000`.

The local development API allows Turnstile to be omitted when `TURNSTILE_SECRET_KEY` is unset. Production deliberately fails closed unless the Turnstile secret is configured. The API also fails closed if Upstash Redis is not configured.

## Production deployment

Deploy to a Node-compatible platform such as Vercel, Render, or another managed Next.js host. GitHub Pages cannot run the API route, middleware session flow, Prisma writes, or Redis rate limiter; use GitHub as the source repository, not as the production host for this full-stack version.

1. Provision managed PostgreSQL and Upstash Redis.
2. Create a Cloudflare Turnstile widget and set both Turnstile keys.
3. Add all environment variables in the hosting dashboard; never commit `.env`.
4. Set `APP_ORIGIN` to the exact canonical origin, including `https://` and no trailing slash.
5. Run `npx prisma migrate deploy` as a release step.
6. Deploy, then test CSP, Turnstile, rate limiting, cookie flags, database failure behavior and accessibility in the real hosted environment.
7. Configure the host/proxy to supply a trustworthy client IP header. The route currently reads `x-forwarded-for`; ensure untrusted clients cannot spoof it at your hosting boundary.
8. Set up log retention, alerts, backups, restore drills, vulnerability scanning, dependency updates and a privacy/data-retention policy before launch.

## Environment variables

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string; use TLS in production. |
| `SESSION_SECRET` | HMAC signing key; at least 32 bytes of high-entropy secret material. |
| `APP_ORIGIN` | Exact origin used for the API Origin check. |
| `UPSTASH_REDIS_REST_URL` | Upstash Redis REST endpoint for rate limiting. |
| `UPSTASH_REDIS_REST_TOKEN` | Secret Redis REST token. |
| `TURNSTILE_SECRET_KEY` | Server-side Cloudflare Turnstile verification secret. |
| `NEXT_PUBLIC_TURNSTILE_SITE_KEY` | Public Turnstile site key for the browser widget. |

## Security notes / production hardening checklist

- **Do not hash customer names, emails or phone numbers as if they were passwords.** Passwords are not collected by this gate. If real accounts are added, hash passwords server-side with Argon2id or bcrypt and never implement client-side password hashing as a substitute for TLS.
- `hashForAudit` creates a keyed SHA-256 pseudonymous identifier for audit correlation; it is not password storage and can still be personal data under privacy law.
- The gate challenge answers are checked server-side, but general-knowledge questions are not a robust CAPTCHA. Keep Turnstile enabled in production and consider replacing the questions with a privacy-reviewed challenge.
- Session JWT is short-lived and stored in an HttpOnly, SameSite=Lax cookie. Add logout, token revocation/rotation, and authorization checks for any protected routes before treating it as full session management.
- The rate limiter is IP-scoped. Add per-account limits after account authentication is implemented, and ensure IP extraction only trusts your hosting proxy.
- CSRF/origin protection is implemented for the gate POST using exact `Origin` comparison and SameSite cookies. Add a synchronizer token or another documented CSRF strategy for future state-changing authenticated routes.
- CSP and security headers are set in `middleware.ts`. Validate the actual policy with your hosting setup; third-party scripts, inline styles, analytics or embeds may need carefully reviewed nonces/allowlists. Avoid adding `'unsafe-eval'`.
- SQL writes use Prisma's parameterized query API. Do not build raw SQL with user input.
- There is no browser fingerprinting, DevTools blocking, invisible screenshot watermarking or right-click blocking. These controls are invasive or easy to bypass and are not reliable security boundaries.
- Consent text is illustrative. Add a real privacy notice, purpose limitation, retention/deletion workflows and a contact for privacy requests before collecting personal data.
- Perform an independent security review and automated tests before handling sensitive or high-volume data.

## Animation and accessibility

- `components/LeafCanvas.tsx` draws five leaf silhouettes, limits active leaves to 30, reuses a single canvas, and uses `requestAnimationFrame`. Click creates a small particle burst and pool ripple; double-click animates a butterfly-like shape; pointer proximity affects leaf motion.
- `components/Scene3D.tsx` renders configurable floating 3D orbs and sparkles. Tweak color, scale, position and speed through component props / CSS variables.
- Reduced-motion preference disables the continuous canvas animation and simplifies CSS transitions.
- The theme toggle switches between forest dark and warm ivory light modes. Time-of-day is exposed as a `data-time` attribute for future theme refinement.

## Packages (pinned in package.json)

- Next.js 15.5.4, React 19.1.1, TypeScript 5.9.2
- Three.js 0.180.0, React Three Fiber 9.3.0, Drei 10.7.6
- Framer Motion 12.23.12, GSAP 3.13.0
- React Hook Form 7.62.0, Zod 4.1.5, Zustand 5.0.8
- Prisma 6.16.2, Upstash Redis 1.35.3, Upstash Ratelimit 2.0.6
- jose 6.1.0, bcryptjs 3.0.2

These are pinned starting versions, not a promise that every version remains the newest or free of advisories. Review current advisories and run `npm audit` before deployment. Remove packages not used by your final implementation.

## Known scope boundaries

The current build includes the gate form, a three-question server-checked challenge, consent checkbox, database persistence, audit event, Turnstile hook, IP rate limiting, JWT session cookie, 3D scene, leaf canvas, reveal/hover effects, toast notifications, dark/light toggle and responsive sections. It does not include a complete user/password auth system, a production login/register flip flow, a custom water shader, real sound assets, database retention jobs, 2FA, Cloudflare WAF configuration, or a tested Lighthouse guarantee. Those should be implemented and tested as separate deliverables rather than represented as active when they are not.

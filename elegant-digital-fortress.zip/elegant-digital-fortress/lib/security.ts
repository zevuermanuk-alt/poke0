import { SignJWT } from 'jose';
import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export function hashForAudit(value: string) {
  const key = process.env.SESSION_SECRET;
  if (!key) throw new Error('SESSION_SECRET is not configured');
  return createHash('sha256').update(`${key}:${value}`).digest('hex');
}

export async function createSessionToken(subject: string) {
  const secret = process.env.SESSION_SECRET;
  if (!secret || Buffer.byteLength(secret) < 32) {
    throw new Error('SESSION_SECRET must be at least 32 bytes');
  }
  return new SignJWT({ scope: 'gate:verified' })
    .setProtectedHeader({ alg: 'HS256', typ: 'JWT' })
    .setSubject(subject)
    .setIssuer('elegant-digital-fortress')
    .setAudience('edf-web')
    .setJti(randomBytes(16).toString('hex'))
    .setIssuedAt()
    .setExpirationTime('20m')
    .sign(new TextEncoder().encode(secret));
}

export function safeEqualText(a: string, b: string) {
  // Fixed-length comparison without exposing expected answers to the browser.
  const aa = createHash('sha256').update(a.trim().toLowerCase()).digest();
  const bb = createHash('sha256').update(b.trim().toLowerCase()).digest();
  return timingSafeEqual(aa, bb);
}
